export const clients = [
  {
    name: "HCI Group",
    image: "/images/our-client1.jpg",
    href: "http://www.thehcigroup.com/",
  },
  {
    name: "RAM Modular",
    image: "/images/our-client2.jpg",
    href: "http://rammodular.com/",
  },
  {
    name: "Provider Power",
    image: "/images/our-client4.jpg",
    href: "http://providerpower.com/",
  },
  {
    name: "Prescient Edge",
    image: "/images/our-client5.jpg",
    href: "http://www.prescientedge.com/",
  },
  {
    name: "Go Energies",
    image: "/images/our-client6.jpg",
    href: "http://goenergies.com/",
  },
  {
    name: "Acacia",
    image: "/images/our-client11.jpg",
    href: "http://acacia-inc.com/",
  },
  {
    name: "Daiichi Sankyo",
    image: "/images/daiichi-sanko.png",
    href: "https://www.daiichisankyo.com/",
  },
];
