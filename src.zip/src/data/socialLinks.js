export const socialLinks = [
  {
    href: "https://www.facebook.com/sidagooutsourcing",
    icon: "fa-facebook",
    title: "facebook",
  },
  {
    href: "https://twitter.com/sidagobpo",
    icon: "fa-twitter",
    title: "twitter",
  },
  {
    href: "https://www.linkedin.com/company/sidago-integrated-solutions",
    icon: "fa-linkedin",
    title: "linkedin",
  },
  {
    href: "https://plus.google.com/u/0/116536599190449967608/",
    icon: "fa-google-plus",
    title: "google-plus",
  },
  {
    href: "/blog/",
    icon: "fa-rss",
    title: "rss",
  },
];
