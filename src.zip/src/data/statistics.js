export const statistics = [
  { label: "Cost Savings", percentage: 75, widthClass: "w-[75%]" },
  { label: "Increased Output", percentage: 81, widthClass: "w-[81%]" },
  { label: "Return on Investment", percentage: 87, widthClass: "w-[87%]" },
  { label: "Client Retention", percentage: 92, widthClass: "w-[92%]" },
];
