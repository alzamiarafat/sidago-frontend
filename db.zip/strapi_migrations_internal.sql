INSERT INTO "strapi_migrations_internal" ("id", "name", "time") VALUES (1, '5.0.0-rename-identifiers-longer-than-max-length', '2026-04-27 09:06:26.284');
INSERT INTO "strapi_migrations_internal" ("id", "name", "time") VALUES (2, '5.0.0-02-created-document-id', '2026-04-27 09:06:26.336');
INSERT INTO "strapi_migrations_internal" ("id", "name", "time") VALUES (3, '5.0.0-03-created-locale', '2026-04-27 09:06:26.384');
INSERT INTO "strapi_migrations_internal" ("id", "name", "time") VALUES (4, '5.0.0-04-created-published-at', '2026-04-27 09:06:26.431');
INSERT INTO "strapi_migrations_internal" ("id", "name", "time") VALUES (5, '5.0.0-05-drop-slug-fields-index', '2026-04-27 09:06:26.482');
INSERT INTO "strapi_migrations_internal" ("id", "name", "time") VALUES (6, '5.0.0-06-add-document-id-indexes', '2026-04-27 09:06:26.53');
INSERT INTO "strapi_migrations_internal" ("id", "name", "time") VALUES (7, 'core::5.0.0-discard-drafts', '2026-04-27 09:06:26.582');
