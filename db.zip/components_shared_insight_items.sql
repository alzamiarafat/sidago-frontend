INSERT INTO "components_shared_insight_items" ("id", "title", "href", "sr_text") VALUES (19, 'Digital asset OTC market 2026', '#', NULL);
INSERT INTO "components_shared_insight_items" ("id", "title", "href", "sr_text") VALUES (20, 'Sidago Trader Assessment Day', '#', NULL);
INSERT INTO "components_shared_insight_items" ("id", "title", "href", "sr_text") VALUES (21, 'Introducing NODE Insights', '#', NULL);
INSERT INTO "components_shared_insight_items" ("id", "title", "href", "sr_text") VALUES (22, 'Digital asset OTC market 2026', '#', NULL);
INSERT INTO "components_shared_insight_items" ("id", "title", "href", "sr_text") VALUES (23, 'Sidago Trader Assessment Day', '#', NULL);
INSERT INTO "components_shared_insight_items" ("id", "title", "href", "sr_text") VALUES (24, 'Introducing NODE Insights', '#', NULL);
