INSERT INTO "admin_users_roles_lnk" ("id", "user_id", "role_id", "role_ord", "user_ord") VALUES (1, 1, 1, 1, 1);
